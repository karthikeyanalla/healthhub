const mongoose = require("mongoose");
const Citizen = require('../models/Citizen');

const citizenSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  phone: { type: String, required: true },
  dob: { type: Date, required: true },
  idNumber: { type: String, required: true, unique: true },
  bloodType: { type: String },
  allergies: { type: String },
  medications: { type: String }, 
  uploadedFiles: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'File',
    },
  ]
  
});

module.exports = mongoose.model("Citizen", citizenSchema);
