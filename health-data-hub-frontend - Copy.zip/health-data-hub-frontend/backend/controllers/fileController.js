const File = require('../models/File');
const Citizen = require('../models/Citizen');
const path = require('path');
const fs = require('fs');

exports.uploadFile = async (req, res) => {
  try {
    console.log("📩 Upload request received");

    const citizenId = req.query.citizenId;
    const description = req.query.description || '';

    if (!req.file) {
      console.warn("⚠️ No file found in request");
      return res.status(400).json({ message: "No file uploaded" });
    }

    const newFile = new File({
      fileName: req.file.originalname,
      filePath: req.file.path,
      fileType: req.file.mimetype,
      citizen: null, // will set after lookup
      description,
    });

    // 🔍 Find citizen using idNumber, not _id
    const citizen = await Citizen.findOne({ idNumber: citizenId });
    if (!citizen) {
      console.warn("⚠️ Citizen not found for idNumber:", citizenId);
      return res.status(404).json({ message: "Citizen not found" });
    }

    newFile.citizen = citizen._id; // set actual ObjectId
    await newFile.save();

    citizen.uploadedFiles.push(newFile._id);
    await citizen.save();
    console.log("📎 File linked to citizen:", citizen._id);

    res.status(201).json(newFile);
  } catch (err) {
    console.error("❌ Error uploading file:", err);
    res.status(500).json({ message: err.message });
  }
};

exports.getFileById = async (req, res) => {
  try {
    const file = await File.findById(req.params.id);
    if (!file) {
      return res.status(404).json({ message: "File not found" });
    }

    const filePath = file.filePath;

    // Check if file exists
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: "File not found on server" });
    }

    // Set headers and send the file
    res.setHeader('Content-Type', file.fileType);
    res.download(filePath, file.fileName); // for download
    // OR use: res.sendFile(path.resolve(filePath)); // for direct viewing
  } catch (err) {
    console.error("❌ Error serving file:", err);
    res.status(500).json({ message: err.message });
  }
};
