const Citizen = require('../models/Citizen');
const File = require('../models/File');

const getAllCitizens = async (req, res) => {
  try {
    const citizens = await Citizen.find();
    res.json(citizens);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const createCitizen = async (req, res) => {
  try {
    const citizen = new Citizen(req.body);
    await citizen.save();
    res.status(201).json(citizen);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

const updateCitizen = async (req, res) => {
  try {
    const citizen = await Citizen.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(citizen);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

const deleteCitizen = async (req, res) => {
  try {
    await Citizen.findByIdAndDelete(req.params.id);
    res.json({ message: 'Citizen deleted' });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

const getCitizenFiles = async (req, res) => {
  try {
    const files = await File.find({ citizen: req.params.id });
    res.json(files);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const getCitizenById = async (req, res) => {
  const citizenId = req.params.id;
  console.log("📍 Looking up citizen by ID:", citizenId);

  try {
    const citizen = await Citizen.findOne({ idNumber: citizenId });
    if (!citizen) {
      console.log("⚠️ Citizen not found for ID:", citizenId);
      return res.status(404).json({ message: "Citizen not found" });
    }

    console.log("✅ Citizen found:", citizen);
    res.status(200).json(citizen);
  } catch (error) {
    console.error("❌ Error while fetching citizen:", error.message);
    res.status(500).json({ message: "Server error" });
  }
};

const getCitizenByIdNumber = async (req, res) => {
  try {
    const citizen = await Citizen.findOne({ idNumber: req.params.idNumber }).populate('uploadedFiles');
    if (!citizen) {
      return res.status(404).json({ message: "Citizen not found with that ID number" });
    }
    res.json(citizen);
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};

// ✅ Final export — all functions must be declared before this point
module.exports = {
  getAllCitizens,
  createCitizen,
  updateCitizen,
  deleteCitizen,
  getCitizenFiles,
  getCitizenById,
  getCitizenByIdNumber,
};
