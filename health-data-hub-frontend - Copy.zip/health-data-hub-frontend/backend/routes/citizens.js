const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const citizenController = require('../controllers/citizenController');
const authMiddleware = require('../middleware/auth');


router.get('/', auth, citizenController.getAllCitizens);
router.post('/', auth, citizenController.createCitizen);
router.put('/:id', auth, citizenController.updateCitizen);
router.delete('/:id', auth, citizenController.deleteCitizen);
router.get('/:id/files', auth, citizenController.getCitizenFiles);
router.get('/:id', auth, citizenController.getCitizenById);
router.get('/idNumber/:idNumber', citizenController.getCitizenByIdNumber);

module.exports = router;
