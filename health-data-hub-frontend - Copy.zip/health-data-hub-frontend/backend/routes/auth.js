const express = require("express");
const router = express.Router();
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const HospitalStaff = require("../models/HospitalStaff");

// REGISTER
router.post("/register", async (req, res) => {
  const { name, hospitalName, email, password, role } = req.body;

  try {
    // Check if the user already exists
    const existingUser = await HospitalStaff.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "User already exists" });
    }

    // Create a new user
    const newUser = new HospitalStaff({
      name,
      hospitalName,
      email,
      password, // plain password — will be hashed by schema pre-save hook
      role,
    });

    // Save the user to the database
    await newUser.save();

    res.status(201).json({ message: "Hospital Staff Registered" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server Error" });
  }
});


// LOGIN
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await HospitalStaff.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: "Invalid email or password" });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid email or password" });
    }

    const token = jwt.sign(
      { id: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );

    res.json({
      token,
      user: {
        id: user._id,
        name: user.name,
        role: user.role,
        email: user.email,
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server Error" });
  }
});

module.exports = router;
