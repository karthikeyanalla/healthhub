const express = require('express');
const router = express.Router();
const Citizen = require('../models/Citizen');

// Simple shared PIN — in production, store in env or DB
const EMERGENCY_PINS = ['1234', '5678'];

router.post('/access', async (req, res) => {
    const { pin, idNumber } = req.body;

    if (!EMERGENCY_PINS.includes(pin)) {
        return res.status(401).json({ error: "Invalid Emergency PIN" });
    }

    try {
        const citizen = await Citizen.findOne({ idNumber }).populate('uploadedFiles');
        if (!citizen) return res.status(404).json({ error: "Citizen not found" });

        // Send only emergency-safe info
        const safeData = {
            name: citizen.name,
            bloodType: citizen.bloodType,
            medications: citizen.medications,
            allergies: citizen.allergies
        };

        res.json(safeData);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Server error" });
    }
});

module.exports = router;
